# Grok Build 源码讲解图集（第二批）

独立图：

- 07 Full-Replace Compaction
- 08 Memory Hybrid Search & Dream
- 09 Hooks Policy Pipeline
- 10 Sandbox Enforcement
- 11 Crash Handler Lifecycle
- 12 Background Tasks & Scheduler
- 13 Plugin Trust & Marketplace

每张图同时提供 PNG、SVG 和 DOT 源文件。
